from django.contrib import admin
from .models import *


admin.site.register([
    Quiz,
    Type,
    Category,
    Answer,
    Submit
])
